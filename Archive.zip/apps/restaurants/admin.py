from django.contrib import admin
from .models import Restaurant, RestaurantImage, Menu, MenuItem, MenuItemIngredient


@admin.register(Restaurant)
class RestaurantAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'phone_number', 'email', 'is_active')
    search_fields = ('name', 'address', 'phone_number', 'email')
    list_filter = ('is_active',)
    ordering = ('name',)
@admin.register(RestaurantImage)
class RestaurantImageAdmin(admin.ModelAdmin):
    list_display = ('restaurant', 'is_primary')
    search_fields = ('restaurant__name',)
    list_filter = ('is_primary',)
    ordering = ('restaurant',)
@admin.register(Menu)
class MenuAdmin(admin.ModelAdmin):
    list_display = ('name', 'restaurant')
    search_fields = ('name', 'restaurant__name')
    list_filter = ('restaurant',)
    ordering = ('restaurant', 'name')
@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'menu', 'price', 'is_available')
    search_fields = ('name', 'menu__name')
    list_filter = ('menu', 'is_available')
    ordering = ('menu', 'name')
@admin.register(MenuItemIngredient)
class MenuItemIngredientAdmin(admin.ModelAdmin):
    list_display = ('name', 'menu_item', 'quantity')
    search_fields = ('name', 'menu_item__name')
    list_filter = ('menu_item',)
    ordering = ('menu_item', 'name')
