from .login import LoginAPITestCase
from .register import RegisterAPITestCase
from .accountstatus import AccountStatusViewTestCase
from .emailexist import EmailExistenceTestCase
from .userddetail import UserDetailAPITestCase
